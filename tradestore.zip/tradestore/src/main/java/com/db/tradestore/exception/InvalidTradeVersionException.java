package com.db.tradestore.exception;

public class InvalidTradeVersionException extends  RuntimeException{

}
