package com.db.tradestore.exception;

public class InvalidRequestBodyException extends  RuntimeException{

}
