package com.db.tradestore.service;

import com.db.tradestore.model.TradeInfo;

public interface TradeStoreService {

  TradeInfo createTrade(TradeInfo tradeInfo);

}
