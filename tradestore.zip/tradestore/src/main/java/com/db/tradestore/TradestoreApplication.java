package com.db.tradestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradestoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradestoreApplication.class, args);
	}

}
